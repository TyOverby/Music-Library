import java.io.File;

import java.io.FileNotFoundException;

import java.util.ArrayList;
import java.util.StringTokenizer;

import java.util.Scanner;

import javax.swing.table.DefaultTableModel;




public class CSVReader {
	public CSVReader() {
		
	
	}
	public static void main (String []args) {
		CSVReader CSVReader = new CSVReader();
	}
}