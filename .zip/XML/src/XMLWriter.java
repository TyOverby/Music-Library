import java.io.*;
import org.w3c.dom.*;
import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class XMLWriter {
	DocumentBuilder docBuilder;
	Document doc;
	DocumentBuilderFactory dbf;
	Element root;
	Element child;
	Element subChild;
	Element subSubChild;

	public XMLWriter(String root) throws ParserConfigurationException, TransformerException {
		dbf = DocumentBuilderFactory.newInstance();
		docBuilder = dbf.newDocumentBuilder();
		doc = docBuilder.newDocument();
		this.root = doc.createElement(root);
		doc.appendChild(this.root);
	
	}
	public void addRoot(String root) {
		this.root = doc.createElement(root);
		doc.appendChild(this.root);
	}
	public void addChild (Element parent, String element, String text) {
		child = doc.createElement(element);
		//sets attribute 
		//child.setAttribute(element, "attribbute");
		Text t = doc.createTextNode(text);
		child.appendChild(t);
		parent.appendChild(child);
	}
	public void addChild (Element parent, String element) {
		child = doc.createElement(element);
		parent.appendChild(child);
	}
	public void addSubChild (Element parent, String element, String text) {
		subChild = doc.createElement(element);
		Text t = doc.createTextNode(text);
		subChild.appendChild(t);
		parent.appendChild(subChild);
	}
	public void addSubChild (Element parent, String element) {
		subChild = doc.createElement(element);
		parent.appendChild(subChild);
		
	}
	public void addSubSubChild (Element parent, String element, String text) {
		subChild = doc.createElement(element);
		Text t = doc.createTextNode(text);
		subChild.appendChild(t);
		parent.appendChild(subChild);
	}
	public void addSubSubChild (Element parent, String element) {
		subChild = doc.createElement(element);
		parent.appendChild(subChild);
		
	}
	private String createString() throws TransformerException {
		TransformerFactory transformerfactory = TransformerFactory.newInstance();
		Transformer transformer = transformerfactory.newTransformer();
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");

		StringWriter sw = new StringWriter();
		StreamResult result = new StreamResult(sw);
		DOMSource source = new DOMSource(doc);
		transformer.transform(source, result);
		String xmlString = sw.toString();

		return xmlString;
	}
	public void printString() {
		try {
			System.out.println(createString());
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void writeFile(String fileName) throws IOException {
		File newFile;
		newFile = new File(fileName);
		FileWriter fw = new FileWriter (newFile);
		BufferedWriter bw = new BufferedWriter (fw);

		try {
			bw.write(createString());
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		bw.close();
		fw.close();
	}}