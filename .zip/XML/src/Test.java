import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;


public class Test {
	public static void main(String []args) throws ParserConfigurationException, TransformerException {
		XMLWriter xmlwriter;
		xmlwriter = new XMLWriter("Music");
		
		xmlwriter.addChild(xmlwriter.root, "Artists");
		xmlwriter.addSubChild(xmlwriter.child, "Albums", "Example Album");
		xmlwriter.addSubSubChild(xmlwriter.child, "Songs", "Example Song");
		
		xmlwriter.printString();
		try {
			xmlwriter.writeFile("music.xml");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
