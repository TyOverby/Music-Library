/**
 * 
 * @author Tim Mikeladze
 *
 */
import java.util.Random;
public class Week08b {
	int length, maxvalue; 
	public Week08b() {
		//creates a new random array of length 20 and max value 200
		int[] myArray = getRandomIntArray(20,200);
		//displays the array
		displayIntArray(myArray);
		int max,min,sum;
		double average;
		//sets the max
		max = myArray[findMax(myArray)];
		//sets the min 
		min = getMin(myArray);
		//sets the sum
		sum = calcSum(myArray);
		//divides the sum by the array's length to find the average
		average = sum / myArray.length;
		//displays all the calculations
		System.out.println("Max value: " + max + "  Min value: " + min);
		System.out.println("Sum: " + sum + "  Average: " + average);

	}

	// creates a random array of certain length and max value
	public static int[] getRandomIntArray(int length, int maxvalue)
	{
		int[] a = new int[length];
		//random generator to create random values
		Random generator = new Random();
		//loops through each member of the array
		for (int i = 0; i < a.length; i++)
		{
			//generates a random number and sets the value of the array
			a[i] = generator.nextInt(maxvalue);
		}
		return a;
	}

	//displays the array
	public static void displayIntArray(int[] array) {
		//loops through and prints out the index and value of each member of the array
		for (int i=0; i<array.length; i++) {
			System.out.println("Index: " + i + " Value: " + array[i]);
		} 

	}
	
	//finds the max value of the array
	public static int findMax(int[] array) {
		int max = 0;
		int maxIndex = 0;
		//loops through the array and find the max value and it's index
		for(int i = 0; i<array.length; i++){
			if(array[i]>  max){
				//sets the max value
				max=array[i];  
				//sets the index
				maxIndex = i;
			}
		}
		//returns the maxIndex
		return maxIndex;
	}
	
	//finds the min value and index 
	public static int getMin(int[] array) {
		int min = 199;
		int minIndex = 0;
		//similiar to findMax but works backwards
		for(int i = 0; i <array.length; i++){
			if(array[i] < min){
				min=array[i];  
				minIndex = i;
			}
		}
		//returns the min value
		return min;
	}
	
	//calculates the sum
	public static int calcSum(int[] array) { 
		int sum = 0;
		//adds up all elements of the array with a loop as long as i is less than the array's length
		for (int i = 0; i < array.length; i++) { 
			sum += array[i];
		}
		return sum;
	}
	
	public static void main(String []args) {
		System.out.println("Tim Mikeladze Week08b");
		Week08b Week08b = new Week08b();
	}
}